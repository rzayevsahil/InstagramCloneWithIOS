//
//  KullaniciAraController.swift
//  InstagramClone
//
//  Created by Sahil Rzayev on 6/1/22.
//

import UIKit
import Firebase

class KullaniciAraController : UICollectionViewController, UISearchBarDelegate {
    //lazy var - aynı hiyerarşide tanımlanmış olan nesneleri kullanma imkanına kavuşuyorum
    lazy var searchBar : UISearchBar = {
        let sb = UISearchBar()
        sb.placeholder = "Kullanıcı adını giriniz"
        UITextField.appearance(whenContainedInInstancesOf: [UISearchBar.self]).backgroundColor = UIColor.rgbDonustur(red: 230, green: 230, blue: 230)
        sb.delegate = self//let olarak tanımlasam bu satır hata verirdi. o yüzden lazy var kullandım
        return sb
    }()
    
    //kullanıcı arama kısmına değer girdiğinde bu metot tetiklenir
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        if searchText.isEmpty {
            filtrelenmisKullanicilar = kullanicilar
        } else {
            self.filtrelenmisKullanicilar = kullanicilar.filter({ kullanici in
                return kullanici.kullaniciAdi.contains(searchText.lowercased())//girilen değer göre kullanıcı bulma
            })
        }
        
        self.collectionView.reloadData()
    }
    
    let hucreID = "hucreID"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.backgroundColor = .white
        
        navigationController?.navigationBar.addSubview(searchBar)
        let navBar = navigationController?.navigationBar
        searchBar.anchor(top: navBar?.topAnchor, bottom: navBar?.bottomAnchor, leading: navBar?.leadingAnchor, trailing: navBar?.trailingAnchor, paddingTop: 0, paddingBottom: 0, paddingLeft: 10, paddingRight: -10, width: 0, height: 0)
        
        collectionView.register(KullaniciAraCell.self, forCellWithReuseIdentifier: hucreID)
        collectionView.alwaysBounceVertical = true//scrollbar ekledim
        collectionView.keyboardDismissMode = .onDrag//scrolla aşağıya kaydırırken kavyenin gözükememsini sağlamak
        
        kullanicilariGetir()
        
        
    }
    
    //her seferinde arama ekranı görüntülendiğinden burası tetikleniyor
    override func viewWillAppear(_ animated: Bool) {
        //o yüzden arama yeri gözüksün
        searchBar.isHidden = false
    }
    
    var filtrelenmisKullanicilar = [Kullanici]()
    var kullanicilar = [Kullanici]()
    
    //arama kısmında yazdığımız kullanıcıları getirecek
    fileprivate func kullanicilariGetir(){
        Firestore.firestore().collection("Kullanicilar").getDocuments { queryShapshot, hata in
            if let hata = hata {
                print("Kullanıcı bilgileri getirilirken hata meydana geldi: \(hata.localizedDescription)")
                return
            }
            
            queryShapshot?.documentChanges.forEach({ degisiklik in
                if degisiklik.type == .added {
                    let kullanici = Kullanici(kullaniciVerisi: degisiklik.document.data())
                    if kullanici.kullaniciID != Auth.auth().currentUser?.uid{
                        self.kullanicilar.append(kullanici)
                    }
                }
            })
            
            //kullanıcıları alfabetik olarak sıralama
            self.kullanicilar.sort { k1, k2 in
                return k1.kullaniciAdi.compare(k2.kullaniciAdi) == .orderedAscending
            }
            //default olarak tüm kullanıcılar gelecek ara kısmında hiçbirşey yazılmazsa
            self.filtrelenmisKullanicilar = self.kullanicilar
            self.collectionView.reloadData()
        }
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return filtrelenmisKullanicilar.count
    }
    //hücre oluşturma
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: hucreID, for: indexPath) as! KullaniciAraCell
        cell.kullanici = filtrelenmisKullanicilar[indexPath.row]
        return cell
    }
    
    //seçilen kullanıcını(yani hücrenin) tetiklendiği kısım
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        //kullanıcının üzerine tıklayıp profikine gitdiğinde searchbar'ı kaldırıyoruz ki prof sayfasında gözükmesin
        searchBar.isHidden = true
        //diğer sayfaya geçtiğimide sanki arama yaparmış gibi klavye açılıyor. onun önüne geçmek için bunu yaptım
        searchBar.resignFirstResponder()
        let kullanici = filtrelenmisKullanicilar[indexPath.row]
        let kullaniciProfilController = KullaniciProfilController(collectionViewLayout: UICollectionViewFlowLayout())
        //kullaniciprofilcontroller'a bunu gönderiyoruz. sebep arama kısmında bulduğumuz kullanıcının profil sayfasına gitmek için
        kullaniciProfilController.kullaniciID = kullanici.kullaniciID
        navigationController?.pushViewController(kullaniciProfilController, animated: true)
    }
    
}

extension KullaniciAraController : UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: view.frame.width, height: 70)
    }
}
