//
//  FotografSeciciController.swift
//  InstagramClone
//
//  Created by Sahil Rzayev on 5/29/22.
//

import UIKit
import Photos

class FotografSeciciController : UICollectionViewController {
    
    let hucreID = "hucreID"
    let headerID = "headerID"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.backgroundColor = .white
        butonlariEkle()
        
        collectionView.register(FotografSeciciCell.self, forCellWithReuseIdentifier: hucreID)
        collectionView.register(FotografSeciciHeader.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: headerID)
        
        fotograflariGetir()
    }
    //aşağıdan gelen fotoğrafı tıklamakla header alanına ekleme çalışıyoruz
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        secilenFotograf = fotograflar[indexPath.row]
        collectionView.reloadData()//her defa foto seçtiğimizde alan güncellensin
        //gidib aşağıdan foto seçtiğimizde bile otomatik olarak yukarı kaydırsın ve header alanında seçtiğimiz fotonu göstersin(kısaca en üst tarafa konumlandırılsın) diye böyle bir metod kullandım
        let indexUst = IndexPath(item: 0, section: 0)
        collectionView.scrollToItem(at: indexUst, at: .bottom, animated: true)
    }
    
    var assetler = [PHAsset]()
    var secilenFotograf : UIImage?
    var fotograflar = [UIImage]()
    
    fileprivate func fotografGetirmeSecenekOlustur() -> PHFetchOptions {
        let getirmeSecenekleri = PHFetchOptions()
        getirmeSecenekleri.fetchLimit = 40//hepsini değil de sadece 40 foto getir,max da yazabiliriz
        let siralamaAyari = NSSortDescriptor(key: "creationDate", ascending: false)
        getirmeSecenekleri.sortDescriptors = [siralamaAyari]//zamana göre foto getiriliyor
        return getirmeSecenekleri
    }
    
    //galerideki fotoğrafları getirme
    fileprivate func fotograflariGetir(){
        
        
        
        let fotograflar = PHAsset.fetchAssets(with: .image, options: fotografGetirmeSecenekOlustur())//sadece fotoları getir
        
        //altdaki ekleme iconun tıkladığımızda fotoğraflar yükleme yaptığı için bizi bekletiyor. onun önüne geçmek içi bunu kullanıyorum. ve bu metot foto getirme işlemini arka planda yapıcak
        DispatchQueue.global(qos: .background).async {
            
            fotograflar.enumerateObjects { asset, sayi, durmaNoktasi in
                //print(asset)//asset içinde tüm fotolerın bilgileri yer alıyor
                //sayi - kaçıncı foto getiriliyor. 0'dan başlar 9'a kadar gider
                //durmaNoktasi - foto getirilirken durulan noktanın adresini tutar
                //print("\(sayi).foto getirildi")
                
                let imageManager = PHImageManager.default()
                let goruntuBoyutu = CGSize(width: 200, height: 200)
                let secenekler = PHImageRequestOptions()
                secenekler.isSynchronous = true//yukardaki fetch limi değerine göre senkron bir şekilde getirecek
                imageManager.requestImage(for: asset, targetSize: goruntuBoyutu, contentMode: .aspectFit, options: secenekler) { goruntu, goruntuBilgileri in
                    if let fotograf = goruntu {
                        self.assetler.append(asset)//tüm küçük görüntü ve onlarla ilgili diğer bilgileri elde ediyorum
                        self.fotograflar.append(fotograf)
                        
                        if self.secilenFotograf == nil {
                            self.secilenFotograf = goruntu//default olarak ilk resmi atıyoruz
                        }
                    }
                    
                    if sayi == fotograflar.count-1 {
                        DispatchQueue.main.async {
                            self.collectionView.reloadData()
                        }
                    }
                }
            }
            
        }
        
    }
    
    //---------------------------- header alanı -----------------------------------
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        //header'ın oluşmasını tetikleyecek ve boyut ataması yapacak metod
        let genislik = view.frame.width
        return CGSize(width: genislik, height: genislik)
    }
    //header alanını diğer alandan ayırmak için boşluk bırakmak
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 1, left: 0, bottom: 0, right: 0)
    }
    
    var header : FotografSeciciHeader?
    
    override func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: headerID, for: indexPath) as! FotografSeciciHeader
        self.header = header
        header.imgHeader.image = secilenFotograf
        
        //header.imgHeader.image = secilenFotograf//seçilen fotonun header'a eklendiği yer
        
        //ilk önce boyutu 200 verdiğimiz için düşük çözünürlükde hücrelere foto getiriliyor. sonra 600 çözünürlükde foto headera ekleniyor. böylece ekle menüsüne geldiğiizde daha hızlı geliyoruz ve sayfayı bembeyaz görmüyoruz
        if let secilenFotograf = secilenFotograf {
            if let index = self.fotograflar.firstIndex(of: secilenFotograf) {
                let secilenAsset = self.assetler[index]
                
                let fotoManager = PHImageManager.default()
                let boyut = CGSize(width: 600, height: 600)
                fotoManager.requestImage(for: secilenAsset, targetSize: boyut, contentMode: .default, options: nil) { foto, bilgi in
                    header.imgHeader.image = foto
                }
            }
        }
        
        return header
    }
    
    //----------------------------------------------------------------------
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return fotograflar.count //hücre sayısıfoto sayısı kadar
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let hucre = collectionView.dequeueReusableCell(withReuseIdentifier: hucreID, for: indexPath) as! FotografSeciciCell//resimleri galeriden getirme
        //hucre.backgroundColor = .brown
        hucre.imgFotograf.image = fotograflar[indexPath.row]
        return hucre
    }
    
    //telefonun şarj,saat gösteren en üst kısmı gitsin istiyorum
    override var prefersStatusBarHidden: Bool{
        return true
    }
    
    fileprivate func butonlariEkle(){
        navigationController?.navigationBar.tintColor = .black
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "İptal et", style: .plain, target: self, action: #selector(btnIptalPressed))
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Sonraki", style: .plain, target: self, action: #selector(btnSonrakiPressed))
    }
    
    @objc fileprivate func btnSonrakiPressed(){
        let fotografPaylasController = FotografPaylasController()
        fotografPaylasController.secilenFotograf = header?.imgHeader.image//fotopaylascontroller'a seçilen resmi gnderiyoruz
        navigationController?.pushViewController(fotografPaylasController, animated: true)
    }
    
    @objc fileprivate func btnIptalPressed(){
        dismiss(animated: true, completion: nil)
    }
    
}

//status barı kaldırmak için bunu yaptım
extension UINavigationController {
    open override var childForStatusBarHidden: UIViewController? {
        return self.topViewController
    }
}

//hücreleri boyutlandırma
extension FotografSeciciController : UICollectionViewDelegateFlowLayout {
    
    //hücreler arası boşluk
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 1
    }
    
    //hücrelerin sağ ve solundaki boşlukları düzenlemek
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let genislik = (view.frame.width - 3) / 4 //her ekrana 4 foto
        return CGSize(width: genislik, height: genislik)
    }
}
