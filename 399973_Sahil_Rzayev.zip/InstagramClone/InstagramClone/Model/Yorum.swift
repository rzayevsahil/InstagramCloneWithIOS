//
//  Yorum.swift
//  InstagramClone
//
//  Created by Sahil Rzayev on 6/3/22.
//

import Foundation

/*struct Yorum {
    
    /*let yorumMesaji : String
    let kullaniciID : String
    
    init(sozlukVerisi : [String : Any]) {
        self.yorumMesaji = sozlukVerisi["yorumMesaji"] as? String ?? ""
        self.kullaniciID = sozlukVerisi["kullaniciID"] as? String ?? ""
    }*/
}
*/
