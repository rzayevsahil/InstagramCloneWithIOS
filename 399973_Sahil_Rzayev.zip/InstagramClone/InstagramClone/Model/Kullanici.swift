//
//  Kullanici.swift
//  InstagramClone
//
//  Created by Sahil Rzayev on 5/4/22.
//

import Foundation

struct Kullanici {
    let kullaniciAdi : String
    let kullaniciID : String
    let profilGoruntuURL : String
    let takipSayisi : String?
    let takipciSayisi : String?
    let paylasimSayisi : String?
    //initialize     key değeri-string,value değeri-any
    init(kullaniciVerisi : [String : Any]) {
        self.kullaniciAdi = kullaniciVerisi["KullaniciAdi"] as? String ?? ""
        self.kullaniciID = kullaniciVerisi["KullaniciID"] as? String ?? ""
        self.profilGoruntuURL = kullaniciVerisi["ProfilGoruntuURL"] as? String ?? ""
        self.takipSayisi = kullaniciVerisi["TakipSayisi"] as? String ?? ""
        self.takipciSayisi = kullaniciVerisi["TakipciSayisi"] as? String ?? ""
        self.paylasimSayisi = kullaniciVerisi["PaylasimSayisi"] as? String ?? ""
    }
}
