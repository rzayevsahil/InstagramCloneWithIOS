//
//  Uzanti+UIColor.swift
//  InstagramClone
//
//  Created by Sahil Rzayev on 4/27/22.
//

import Foundation
import UIKit

extension UIColor{
    
    static func anaMavi() -> UIColor {
        return UIColor.rgbDonustur(red: 20, green: 155, blue: 235)
    }
    
    static func rgbDonustur(red:CGFloat, green:CGFloat, blue:CGFloat)-> UIColor {
        return UIColor(red:red/255, green: green/255, blue: blue/255, alpha: 1)
    }
}
