//
//  Uzanti+Firestore.swift
//  InstagramClone
//
//  Created by Sahil Rzayev on 6/2/22.
//

import Firebase

extension Firestore {
    //completion kısmında çalıştıracak bu fonksiyonu, ->() her hangi bişey return etmeyecek
    static func kullaniciOlustur(kullaniciID : String = "", completion : @escaping (Kullanici) -> ()) {
        var kID = ""
        if kullaniciID == "" {
            guard let gecerliKullaniciID = Auth.auth().currentUser?.uid else {return}
            kID = gecerliKullaniciID
        } else {
            kID = kullaniciID
        }
        
        Firestore.firestore().collection("Kullanicilar").document(kID).getDocument { snapshot, hata in
            if let hata = hata {
                print("Kullanıcı bilgileri getirilemedi: ",hata.localizedDescription)
                return
            }
            
            guard let kullaniciVerisi = snapshot?.data() else {return}
            let kullanici = Kullanici(kullaniciVerisi: kullaniciVerisi)
            completion(kullanici)//bu blokda bunları kullana bilecek
        }
    }
}
