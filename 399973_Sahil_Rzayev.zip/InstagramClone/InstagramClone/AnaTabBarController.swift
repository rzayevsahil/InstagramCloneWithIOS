//
//  AnaTabBarController.swift
//  InstagramClone
//
//  Created by Sahil Rzayev on 5/4/22.
//

import Foundation
import UIKit
import Firebase

class AnaTabBarController :UITabBarController {
    override func viewDidLoad() {
        super.viewDidLoad()
        self.delegate = self
        if Auth.auth().currentUser == nil {
            //demek ki oturumu açan herhangi bir kullanıcı yok
            //main controller'lar yüklendikten sonra bu controller yüklensin diyoruz aksi takdirde yüklenmiyor
            oturumAc()
            return
            
        }
        
        gorunumuOlustur()
    }
    
    func gorunumuOlustur(){
        
        let anaNavController = navControllerOlustur(image: #imageLiteral(resourceName: "Ana_Ekran_Secili_Degil"), selectedImage: #imageLiteral(resourceName: "Ana_Ekran_Secili"), rootViewController: AnaController(collectionViewLayout: UICollectionViewFlowLayout()))
        
        let araNavController = navControllerOlustur(image: #imageLiteral(resourceName: "Ara_Secili_Degil"), selectedImage: #imageLiteral(resourceName: "Ara_Secili"), rootViewController: KullaniciAraController(collectionViewLayout: UICollectionViewFlowLayout()))
        
        let ekleNavController = navControllerOlustur(image: #imageLiteral(resourceName: "Ekle_Secili_Degil"), selectedImage: #imageLiteral(resourceName: "Ekle_Secili"))
        
        let begeniNavController = navControllerOlustur(image: #imageLiteral(resourceName: "Begeni_Secili_Degil"), selectedImage: #imageLiteral(resourceName: "Begeni_Secili"))
        
        let layout = UICollectionViewFlowLayout()
        let kullaniciProfilController = KullaniciProfilController(collectionViewLayout: layout)
        let kullaniciProfilNavController = UINavigationController(rootViewController: kullaniciProfilController)
        //navigationcontroller'ın satarımda üst tarafı navigationbar alt kısmı tabbar oluyor
        kullaniciProfilNavController.tabBarItem.image = #imageLiteral(resourceName: "Profil")
        kullaniciProfilNavController.tabBarItem.selectedImage = #imageLiteral(resourceName: "Profil_Secili")
        tabBar.tintColor = .black
        viewControllers = [anaNavController, araNavController, ekleNavController, begeniNavController, kullaniciProfilNavController]
        
        guard let items = tabBar.items else {return}
        for item in items {
            //iconlara yukardan boşluk verme
            //butonları aşağı boşluk verirken aşağıdan sınırlandırıldığı için küçüldüler. bu yüzden bottomu genişletmek amaçlı eksi değer verdim
            item.imageInsets = UIEdgeInsets(top: 5, left: 0, bottom: -5, right: 0)
        }
    }
    
    fileprivate func navControllerOlustur(image:UIImage, selectedImage:UIImage, rootViewController:UIViewController=UIViewController())-> UINavigationController{
        let rootController = rootViewController
        let navController = UINavigationController(rootViewController: rootController)
        navController.tabBarItem.image = image
        navController.tabBarItem.selectedImage = selectedImage
        return navController
    }
    
    func oturumAc(){
        DispatchQueue.main.async {
            let oturumAcController = OturumAcController()
            //yukardan aşağıya doğru elimizle çektiğimizde pencere aşağıya doğru kayıyor ve bunun önüne keçmek için altdaki kodu ekliyorum
            //oturumAcController.modalPresentationStyle = .fullScreen
            //kayitOlController kısmına navigationController nil olarak gidiyor diye burda böyle bişey yazıyoruz
            let navController = UINavigationController(rootViewController: oturumAcController)
            navController.modalPresentationStyle = .fullScreen
            //present ile ekrana gösteriyoruz bu controller'ı
            self.present(navController, animated: true, completion: nil)
        }
            
        
    }
}

//nav kısmındaki butonlara(item) bastığımızda onu bize haber verecek metot
extension AnaTabBarController : UITabBarControllerDelegate {
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        
        //basılan iconun index'ini alma
        guard let index = viewControllers?.firstIndex(of: viewController) else {return true}
        
        //ekle butonu
        if index == 2 {
            
            let layout = UICollectionViewFlowLayout()
            let fotografSeciciController = FotografSeciciController(collectionViewLayout: layout)
            let navController = UINavigationController(rootViewController: fotografSeciciController)
            navController.modalPresentationStyle = .fullScreen
            present(navController, animated: true, completion: nil)
            //bastığım icon seçilmesin be gösterilen view controller gösterilmesin
            return false
        }
        
        return true
    }
}
