//
//  AnaConroller.swift
//  InstagramClone
//
//  Created by Sahil Rzayev on 6/1/22.
//

import UIKit
import Firebase

class AnaController : UICollectionViewController {
    
    let hucredID = "hucreID"
    
    override func viewDidLoad() {
        
        NotificationCenter.default.addObserver(self, selector: #selector(paylasimlariYenile), name: FotografPaylasController.guncelleNotification, object: nil)
        
        super.viewDidLoad()
        collectionView.backgroundColor = .white
        
        collectionView.register(AnaPaylasimCell.self, forCellWithReuseIdentifier: hucredID)
        
        butonlariOlustur()
        kullaniciGetir() // böyle çağırırsak oturum açan kişinin paylaşımlarını getirir
        takipEdilenKullaniciIDDegerleriGetir()
        
        //ana ekranda sayfayı yukardan aşağıya doğru çektiğinde gerçek instada olduğu gibi verilerin yenilenmesi olayı
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(paylasimlariYenile), for: .valueChanged)
        collectionView.refreshControl = refreshControl
    }
    
    @objc fileprivate func paylasimlariYenile(){
        print("paylaşımlar yenileniyor")
        paylasimlar.removeAll()
        collectionView.reloadData()//reload data yapmazsam hata verir
        takipEdilenKullaniciIDDegerleriGetir()
        kullaniciGetir()
    }
    
    fileprivate func takipEdilenKullaniciIDDegerleriGetir(){
        guard let kID = Auth.auth().currentUser?.uid else {return}
        
        Firestore.firestore().collection("TakipEdiyor").document(kID).addSnapshotListener { documentSnapshot, hata in
            if let hata = hata {
                print("Paylaşımlar getirilirken hata oluştu: ",hata.localizedDescription)
                return
            }
            
            guard let paylasimSozlukVerisi = documentSnapshot?.data() else {return}
            paylasimSozlukVerisi.forEach { (key,value) in
                Firestore.kullaniciOlustur(kullaniciID: key) { kullanici in
                    self.paylasimlariGetir(kullanici: kullanici)
                }
            }
        }
    }
    
    var paylasimlar = [Paylasim]()
    
    fileprivate func paylasimlariGetir(kullanici : Kullanici){

        Firestore.firestore().collection("Paylasimlar").document(kullanici.kullaniciID).collection("Fotograf_Paylasimlari").order(by: "PaylasimTarihi", descending: false).addSnapshotListener { querySanpshot, hata in
            
            self.collectionView.refreshControl?.endRefreshing()//sayfa yenilenirken dönen animasyonu kaldırıyoruz burda
            
            if let hata = hata {
                print("Paylaşımlar getirilirken hata oluştu: ",hata.localizedDescription)
                return
            }
            var sayi=0
            querySanpshot?.documentChanges.forEach({ degisiklik in
                if degisiklik.type == .added {
                    let paylasimVerisi = degisiklik.document.data()
                    var paylasim = Paylasim(kullanici: kullanici, sozlukVerisi: paylasimVerisi)
                    paylasim.id = degisiklik.document.documentID//paylaşım id'si
                    
                    guard let gecerliKullaniciID = Auth.auth().currentUser?.uid else {return}
                    guard let paylasimID = paylasim.id else {return}

                    Firestore.firestore().collection("Begeniler").document(paylasimID).addSnapshotListener { snapshot, hata in
                        if let hata = hata {
                            print("Beğeni verileri alınırken hata meydana geldi: ",hata.localizedDescription)
                            return
                        }
                        
                        let begeniVerisi = snapshot?.data()
                        //print("******* : ",begeniVerisi)
                        //var begeniSayisi = AnaPaylasimCell().lblBegenSayisi.text
                        if let begeniDegeri = begeniVerisi?[gecerliKullaniciID] as? Int, begeniDegeri == 1 {
                            paylasim.begenildi = true
                            sayi+=1
                        } else {
                            paylasim.begenildi = false
                        }
                        self.paylasimlar.append(paylasim)
                        //begeniSayisi = "\(sayi) Beğenme"
                        //print("---- ",begeniSayisi)
                        sayi=0
                        
                        //en yeni paylaşım en sona ekleniyor diye listeyi ters çeviriyorum
                        self.paylasimlar.reverse()
                        //paylaşım tarihine göre sıralama
                        self.paylasimlar.sort { p1, p2 in
                            return p1.paylasimTarihi.dateValue().compare(p2.paylasimTarihi.dateValue()) == .orderedDescending
                        }
                        self.collectionView.reloadData()
                    }
                    
                }
            })
        }
    }
    
    fileprivate func butonlariOlustur() {
        navigationItem.titleView = UIImageView(image: #imageLiteral(resourceName: "Logo_Instagram2"))
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: #imageLiteral(resourceName: "Kamera").withRenderingMode(.alwaysOriginal), style: .plain, target: self, action: #selector(kameraYonet))
    }
    
    @objc fileprivate func kameraYonet() {
        print("kamera butonuna basıldı")
    }
    
    //hücre sayısı
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return paylasimlar.count
    }
    //hücre oluşturma
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let hucre = collectionView.dequeueReusableCell(withReuseIdentifier: hucredID, for: indexPath) as! AnaPaylasimCell
        hucre.paylasim = paylasimlar[indexPath.row]
        hucre.delegate = self//anapaylasimcell'le haberleşme sağlamak için
        return hucre
    }
    
    var gecerliKullanici : Kullanici?
    
    fileprivate func kullaniciGetir(kullaniciID : String = ""){
        guard let gecerliKullaniciID = Auth.auth().currentUser?.uid else {return}
        let kID = kullaniciID == "" ? gecerliKullaniciID : kullaniciID
        Firestore.firestore().collection("Kullanicilar").document(kID).getDocument { snapshot, hata in
            if let hata = hata {
                print("Kullanıcı Bilgileri Getirilemedi: ",hata)
                return
            }
            guard let kullaniciVerisi = snapshot?.data() else {return}
            self.gecerliKullanici = Kullanici(kullaniciVerisi: kullaniciVerisi)
            //optional(?) olmaktan kurtarıyoruz
            guard let kullanici = self.gecerliKullanici else {return}
            self.paylasimlariGetir(kullanici: kullanici)
        }
    }
    
}

extension AnaController : UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        var yukseklik : CGFloat = 55
        yukseklik += view.frame.width//genişlik ne kadarsa paylaşım fotonun yüksekliği de o kadar olsun, imgPaylasimFoto için yani
        yukseklik += 50//paylaşım altındaki buton alanları için yer açtım
        yukseklik += 70 //kullanıcı paylaştığı paylaşım altına yorum eklemesi için alan açtım
        return CGSize(width: view.frame.width, height: yukseklik)
    }
    
}

extension AnaController : AnaPaylasimCellDelegate {    
    
    func paylasimBegenildi(cell: AnaPaylasimCell) {
        
        guard let indexPath = collectionView.indexPath(for: cell) else {return}
        var paylasim = self.paylasimlar[indexPath.row]
        
        guard let paylasimID = paylasim.id else {return}
        guard let gecerliKullaniciID = Auth.auth().currentUser?.uid else {return}
        
        let eklenecekDeger = [gecerliKullaniciID: paylasim.begenildi == true ? 0 : 1]
        
        Firestore.firestore().collection("Begeniler").document(paylasimID).getDocument { snapshot, hata in
            if let hata = hata {
                print("Beğeni verisi alınamadı: ",hata.localizedDescription)
                return
            }
            if snapshot?.exists == true {
                Firestore.firestore().collection("Begeniler").document(paylasimID).updateData(eklenecekDeger) { hata in
                    if let hata = hata {
                        print("Beğeni güncellemesi başarısız: ",hata.localizedDescription)
                        return
                    }
                    
                    print("Paylaşımı beğendin")
                    paylasim.begenildi = !paylasim.begenildi
                    self.paylasimlar[indexPath.row] = paylasim
                    self.collectionView.reloadItems(at: [indexPath])
                }
            } else {
                Firestore.firestore().collection("Begeniler").document(paylasimID).setData(eklenecekDeger) { hata in
                    if let hata = hata {
                        print("Beğeni verisi kaydı başarısız: ",hata.localizedDescription)
                        return
                    }
                    print("Beğeni işlemi başarılı")
                    paylasim.begenildi = !paylasim.begenildi
                    self.paylasimlar[indexPath.row] = paylasim
                    self.collectionView.reloadItems(at: [indexPath])
                }
            }
        }
        
    }
    
    func yorumaBasildi(paylasim :  Paylasim) {
        let yorumlarController = YorumlarController(collectionViewLayout: UICollectionViewLayout())
        yorumlarController.secilenPaylasim = paylasim
        navigationController?.pushViewController(yorumlarController, animated: true)
    }
}
