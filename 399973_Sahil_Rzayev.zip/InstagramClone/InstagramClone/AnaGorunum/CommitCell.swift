//
//  YorumCell.swift
//  InstagramClone
// 
//  Created by Sahil Rzayev on 6/3/22.
// 

import UIKit

class CommitCell : UICollectionViewCell {
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .brown
        print("denemeler")
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
