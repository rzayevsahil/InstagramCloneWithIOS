//
//  YorumlarController.swift
//  InstagramClone
//
//  Created by Sahil Rzayev on 6/3/22.
//

import UIKit
import Firebase

class YorumlarController : UICollectionViewController {
    let eklenenYorumlar = "Eklenen_Yorumlar"
    
    var secilenPaylasim : Paylasim?
    
    let yorumcellID = "yorumCellID"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "Yorumlar"
        
        collectionView.backgroundColor = .green
        print("biz burdayıııız",yorumcellID)
        collectionView.reloadData()
        collectionView.register(CommitCell.self, forCellWithReuseIdentifier: yorumcellID)
        //içerden boşluk verme
        //collectionView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: -80, right: 0)
        //scrolun kaydığı yer
        //collectionView.scrollIndicatorInsets = UIEdgeInsets(top: 0, left: 0, bottom: -80, right: 0)
        
        //yorumlariGetir()
    }
    
    
    //hücre sayısı
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        print("hücre sayısı 20")
        return 20
    }
    
    //hücre oluşturma
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: yorumcellID, for: indexPath) as! CommitCell
        print("---->",yorumcellID)
        return cell
    }
    
    
    //yorumlar ekranından çıktığımızda
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        tabBarController?.tabBar.isHidden = false
    }
    
    //sayfanın kenarında tutup kaydırıp ana sayfaya geldiğimizde tabbar kısmı gözüke bilir.binevi bug gibi
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //alt kısımdaki iconları görünmez yapıyorum
        tabBarController?.tabBar.isHidden = true
    }
    
    
    
    
    /*var yorumlar = [Yorum]()
    fileprivate func yorumlariGetir() {
        guard let paylasimID = self.secilenPaylasim?.id else {return}
        
        Firestore.firestore().collection("Yorumlar").document(paylasimID).collection(eklenenYorumlar).addSnapshotListener { snapshot, hata in
            if let hata = hata {
                print("Yorumları getirirken hata meydana geldi: ",hata.localizedDescription)
                return
            }
            
            snapshot?.documentChanges.forEach({ documentChange in
                
                let sozlukVerisi = documentChange.document.data()
                let yorum = Yorum(sozlukVerisi: sozlukVerisi)
                print(yorum.yorumMesaji," - ",yorum.kullaniciID)
                self.yorumlar.append(yorum)
                self.collectionView.reloadData()
            })
        }
    }*/
    
    lazy var contView : UIView = {
        let containerView = UIView()
        containerView.backgroundColor = .white
        containerView.frame = CGRect(x: 0, y: 0, width: 150, height: 80)
        
        let btnYorumGonder = UIButton(type: .system)
        btnYorumGonder.setTitle("Gönder", for: .normal)
        btnYorumGonder.setTitleColor(.black, for: .normal)
        btnYorumGonder.titleLabel?.font = UIFont.boldSystemFont(ofSize: 17)
        btnYorumGonder.addTarget(self, action: #selector(btnYorumGonderPressed), for: .touchUpInside)
        containerView.addSubview(btnYorumGonder)
        btnYorumGonder.anchor(top: containerView.safeAreaLayoutGuide.topAnchor, bottom: containerView.safeAreaLayoutGuide.bottomAnchor, leading: nil, trailing: containerView.safeAreaLayoutGuide.trailingAnchor, paddingTop: 0, paddingBottom: 0, paddingLeft: 15, paddingRight: -15, width: 80, height: 0)
        
        containerView.addSubview(txtYorum)
        //top->container'ın tamamıma yayılsına göre ayarlandı
        txtYorum.anchor(top: containerView.safeAreaLayoutGuide.topAnchor,
                        bottom: containerView.safeAreaLayoutGuide.bottomAnchor,
                        leading: containerView.safeAreaLayoutGuide.leadingAnchor,
                        trailing: btnYorumGonder.leadingAnchor,
                        paddingTop: 0, paddingBottom: 0, paddingLeft: 3, paddingRight: -3, width: 0, height: 0)
        
        return containerView
    }()
    
    let txtYorum : UITextField = {
        let txt = UITextField()
        txt.placeholder = "Yorum Giriniz..."
        return txt
    }()
    
    @objc fileprivate func btnYorumGonderPressed() {
        if let yorum = txtYorum.text, yorum.isEmpty {
            return
        }
        
        guard let gecerliKullaniciID = Auth.auth().currentUser?.uid else {return}
        
        let paylasimID = self.secilenPaylasim?.id ?? ""
        let eklenecekDeger = ["yorumMesaji" : txtYorum.text ?? "",
        "eklenmeTarihi" : Date().timeIntervalSince1970,
        "kullaniciID" : gecerliKullaniciID] as [String : Any]
        
        //document() - içine bişey eklemezsek firebase otomatik bir değer tanımlar ona id gibi
        Firestore.firestore().collection("Yorumlar").document(paylasimID).collection(eklenenYorumlar).document().setData(eklenecekDeger) { hata in
            if let hata = hata {
                print("Yorum eklenirken hata meydana geldi: ",hata.localizedDescription)
                return
            }
            print("Yorum başarıyla eklendi")
            self.txtYorum.text = ""
        }
    }
    
    
    //ios kendi yapısı bu. klavyenin üzerinde kalıyor yacağımız kısım. otomatik olarak kendini ona göre ayarlıyor
    override var inputAccessoryView: UIView? {
        get {
            return contView
        }
    }
    
    //ekran açılır açılmaz imleç orda konumlansın
    override var canBecomeFirstResponder: Bool {
        return true
    }
    
    
}

extension YorumlarController : UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        print("extension kısmı")
        return CGSize(width: 100, height: 65)
    }
}
