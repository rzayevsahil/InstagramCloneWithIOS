//
//  AnaPaylasimCell.swift
//  InstagramClone
//
//  Created by Sahil Rzayev on 6/1/22.
//

import UIKit
import Firebase

//buton burada tanımlı ama biz bunu anapaylasımcontroler'a bildirmemiz gerekli,çünkü db'ye ordan bağlanıp hangi paylaşıma basıldıysa onun yorumlarını ele alıcaz - haberleşme sistemi kuruyorum
protocol AnaPaylasimCellDelegate {
    func yorumaBasildi(paylasim : Paylasim)
    func paylasimBegenildi(cell : AnaPaylasimCell)
    //func begeniSayisiBulma(paylasim : Paylasim)
}

//not: uicollectionviewcell sadece kullanıcının o anlık gördüğü hücreleri oluşturuyor. kullanıcı diğer hücreleri görmek için sayfayı aşağıya kaydırdkça diğer hücreleri de oluşturuyor

class AnaPaylasimCell : UICollectionViewCell {
   
    var delegate : AnaPaylasimCellDelegate?

    var paylasim : Paylasim? {
        didSet{
            //print("Paylaşım görüntü url: \(paylasim?.paylasimGoruntuURL ?? "Yok")\n")
            guard let url = paylasim?.paylasimGoruntuURL,
                  let goruntuUrl = URL(string: url) else {return}
            imgPaylasimFoto.sd_setImage(with: goruntuUrl, completed: nil)
            
            lblKullaniciAdi.text = paylasim?.kullanici?.kullaniciAdi.lowercased()
            
            guard let pUrl = paylasim?.kullanici?.profilGoruntuURL,
                  let profilGoruntuURL = URL(string: pUrl) else {return}
            imgKullaniciProfilFoto.sd_setImage(with: profilGoruntuURL, completed: nil)
            
            attrPaylasimMesajiOlustur()
            
            if paylasim?.begenildi == true {
                btnBegen.setImage(#imageLiteral(resourceName: "Begeni_Secili").withRenderingMode(.alwaysOriginal), for: .normal)
            } else {
                btnBegen.setImage(#imageLiteral(resourceName: "Begeni_Secili_Degil").withRenderingMode(.alwaysOriginal), for: .normal)
            }
            guard let paylasim = paylasim else {return}
            
            var sayi=0
            Firestore.firestore().collection("Begeniler").document(paylasim.id ?? "").getDocument { querySnapshot, hata in
                if let hata = hata {
                    print("hata: ",hata.localizedDescription)
                    return
                }
                guard let data = querySnapshot?.data() else {return}
                data.forEach { key,value in
                    if value as! Int == 1 {
                        sayi+=1
                    }
                }
                print("begeni sayisi ile ilgili---> ",data,sayi)
                if sayi == 0 {
                    self.lblBegenSayisi.text = "İlk beğenen sen ol"
                } else {
                    self.lblBegenSayisi.text = "\(sayi) Beğenme"
                }
                sayi=0
            }
        }
        
    }
    
    fileprivate func attrPaylasimMesajiOlustur(){
        
        guard let paylasim = self.paylasim else {return}
        
        let attrText = NSMutableAttributedString(string: paylasim.kullanici!.kullaniciAdi.lowercased(), attributes: [.font : UIFont.boldSystemFont(ofSize: 14)])
        attrText.append(NSAttributedString(string: " \(paylasim.mesaj ?? "" )", attributes: [.font : UIFont.systemFont(ofSize: 14)]))
        
        attrText.append((NSAttributedString(string: "\n\n", attributes: [.font : UIFont.systemFont(ofSize: 4)])))
        
        let paylasimZaman = paylasim.paylasimTarihi.dateValue()
        attrText.append(NSAttributedString(string: paylasimZaman.zamanOnceHesap(), attributes: [.font : UIFont.systemFont(ofSize: 14), .foregroundColor : UIColor.gray]))
        
        lblPaylasimMesaj.attributedText = attrText
    }
    
    //---------------------- Paylaşımın alt kısmı ---------------------------
    
    let lblPaylasimMesaj : UILabel = {
        let lbl = UILabel()
        lbl.numberOfLines = 0//eğer taşarsa bir alt satırda görüntülensin
        return lbl
    }()
    
    //yer işareti butonu
    let btnBookmark : UIButton = {
        let btn = UIButton(type: .system)
        btn.setImage(#imageLiteral(resourceName: "Yer_Isareti").withRenderingMode(.alwaysOriginal), for: .normal)
        return btn
    }()
    
    lazy var btnBegen : UIButton = {
        let btn = UIButton(type: .system)
        btn.setImage(#imageLiteral(resourceName: "Begeni_Secili_Degil").withRenderingMode(.alwaysOriginal), for: .normal)
        btn.addTarget(self, action: #selector(btnBegenPressed), for: .touchUpInside)
        return btn
    }()
    
    @objc fileprivate func btnBegenPressed() {
        delegate?.paylasimBegenildi(cell: self)
    }
    
    lazy var btnYorumYap : UIButton = {
        let btn = UIButton(type: .system)
        btn.setImage(#imageLiteral(resourceName: "Yorum").withRenderingMode(.alwaysOriginal), for: .normal)
        btn.addTarget(self, action: #selector(btnYorumYapPressed), for: .touchUpInside)
        return btn
    }()
    
    @objc fileprivate func btnYorumYapPressed(){
        //optional olmaktan kurtarıyorum önce
        guard let paylasim = self.paylasim else {return}
        delegate?.yorumaBasildi(paylasim: paylasim)
    }
    
    
    let btnMesajGonder : UIButton = {
        let btn = UIButton(type: .system)
        btn.setImage(#imageLiteral(resourceName: "Gonder").withRenderingMode(.alwaysOriginal), for: .normal)
        return btn
    }()
    
    //------------------- Paylaşımın üst kısmı ------------------------------
    
    let btnSecenekler : UIButton = {
        let btn = UIButton(type: .system)
        btn.setTitle("•••", for: .normal)
        btn.setTitleColor(.black, for: .normal)
        return btn
    }()
    
    let lblKullaniciAdi : UILabel = {
        let lbl = UILabel()
        lbl.text = "Kullanıcı Adı"
        lbl.font = UIFont.boldSystemFont(ofSize: 15)
        return lbl
    }()
    
    let imgKullaniciProfilFoto : UIImageView = {
        let img = UIImageView()
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        img.backgroundColor = .blue
        return img
    }()
    
    //---------------------------------------------------
    
    let imgPaylasimFoto : UIImageView = {
        let img = UIImageView()
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        return img
    }()
    
    let lblBegenSayisi : UILabel = {
        let lbl = UILabel()
        //lbl.text = "1 Beğenme"
        lbl.font = UIFont.boldSystemFont(ofSize: 15)
        return lbl
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .white
        
        
        addSubview(imgKullaniciProfilFoto)
        addSubview(lblKullaniciAdi)
        addSubview(btnSecenekler)
        addSubview(imgPaylasimFoto)
        
        imgKullaniciProfilFoto.anchor(top: topAnchor, bottom: nil, leading: leadingAnchor, trailing: nil, paddingTop: 8, paddingBottom: 0, paddingLeft: 8, paddingRight: 0, width: 40, height: 40)
        
        imgKullaniciProfilFoto.layer.cornerRadius = 40/2
        
        
        lblKullaniciAdi.anchor(top: topAnchor, bottom: imgPaylasimFoto.topAnchor, leading: imgKullaniciProfilFoto.trailingAnchor, trailing: btnSecenekler.leadingAnchor, paddingTop: 0, paddingBottom: 0, paddingLeft: 8, paddingRight: 0, width: 0, height: 0)
        
        
        btnSecenekler.anchor(top: topAnchor, bottom: imgPaylasimFoto.topAnchor, leading: nil, trailing: trailingAnchor, paddingTop: 0, paddingBottom: 0, paddingLeft: 0, paddingRight: 0, width: 45, height: 0)
        
        //-----------------------------------------------------------------------------------------------
        
        imgPaylasimFoto.anchor(top: imgKullaniciProfilFoto.bottomAnchor, bottom: nil, leading: leadingAnchor, trailing: trailingAnchor, paddingTop: 8, paddingBottom: 0, paddingLeft: 0, paddingRight: 0, width: 0, height: 0)
        
        _ = imgPaylasimFoto.heightAnchor.constraint(equalTo: widthAnchor, multiplier: 1).isActive = true
        
        //-----------------------------------------------------------------------------------------------
        
        etkilesimButonlariOlustur()
    
        
        addSubview(lblPaylasimMesaj)
        lblPaylasimMesaj.anchor(top: lblBegenSayisi.bottomAnchor, bottom: bottomAnchor, leading: leadingAnchor, trailing: trailingAnchor, paddingTop: 0, paddingBottom: 0, paddingLeft: 8, paddingRight: -8, width: 0, height: 0)
        
    }
    
    
    
    fileprivate func etkilesimButonlariOlustur(){
        let stackView = UIStackView(arrangedSubviews: [btnBegen, btnYorumYap, btnMesajGonder])
        stackView.distribution = .fillEqually//alanları eşit olsun
        addSubview(stackView)
        stackView.anchor(top: imgPaylasimFoto.bottomAnchor, bottom: nil, leading: leadingAnchor, trailing: nil, paddingTop: 0, paddingBottom: 0, paddingLeft: 8, paddingRight: 0, width: 120, height: 50)
        
        addSubview(btnBookmark)
        btnBookmark.anchor(top: imgPaylasimFoto.bottomAnchor, bottom: nil, leading: nil, trailing: trailingAnchor, paddingTop: 0, paddingBottom: 0, paddingLeft: 0, paddingRight: 0, width: 40, height: 50)
        
        addSubview(lblBegenSayisi)
        lblBegenSayisi.anchor(top: btnBegen.bottomAnchor, bottom: nil, leading: leadingAnchor, trailing: nil, paddingTop: -5, paddingBottom: 0, paddingLeft: 8, paddingRight: -8, width: 0, height: 0)
        
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
