//
//  KullaniciProfilController.swift
//  InstagramClone
//
//  Created by Sahil Rzayev on 5/4/22.
//

import Foundation
import UIKit
import Firebase
import FirebaseFirestore

class KullaniciProfilController :UICollectionViewController {
    
    let listePaylasimHucreID = "listePaylasimHucreID"
    
    var gridGorunum = true
    
    var kullaniciID : String?
    
    let paylasimHucreID = "paylasimHucreID"
    
    override func viewDidLoad() {
        super.viewDidLoad()        
        collectionView.backgroundColor = .white
        
        kullaniciyiGetir()
        //UICollectionView içine nasıl bir default bir hüzcre oluşturuluyorsa
        //burda da o veri türünden bir veri oluşturucam
        //forSupplementaryViewOfKind - ek olarak oluşturmak istediğin alan hangi türde
        collectionView.register(KullaniciProfilHeader.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "headerID")
        
        collectionView.register(KullaniciPaylasimFotoCell.self, forCellWithReuseIdentifier: paylasimHucreID)
        
        collectionView.register(AnaPaylasimCell.self, forCellWithReuseIdentifier: listePaylasimHucreID)
        
        btnOturumKapatOlustur()
    }
    
    var paylasimlar = [Paylasim]()
    
    fileprivate func paylasimlariGetirFireStore(){
        //guard let gecerliKullaniciID = Auth.auth().currentUser?.uid else {return}
        guard let gecerliKullaniciID = self.gecerliKullanici?.kullaniciID else {return}
        //guard let gecerliKullanici = gecerliKullanici else {return}
        Firestore.firestore().collection("Paylasimlar").document(gecerliKullaniciID).collection("Fotograf_Paylasimlari").order(by: "PaylasimTarihi", descending: false).addSnapshotListener { querySnapshot, hata in
            
            if let hata = hata {
                print("Paylaşımlar getirilirken hata meydana geldi: ",hata)
                return
            }
            querySnapshot?.documentChanges.forEach({ degisiklik in
                //bu veri yeni mi eklenmiş?
                if degisiklik.type == .added {
                    let paylasimVerisi = degisiklik.document.data()
                    let paylasim = Paylasim(kullanici: self.gecerliKullanici!, sozlukVerisi: paylasimVerisi)
                    self.paylasimlar.append(paylasim)
                }
            })
            //tüm paylaşımlar paylaşımlar dizisine aktarıldı
            //reload yaptığı için ters çeviriyorum ki listeyi en son eklenen paylaşım sayfada ilk sırada yer alsın
            self.paylasimlar.reverse()
            self.collectionView.reloadData()
        }
    }
    
    fileprivate func btnOturumKapatOlustur(){
        navigationItem.rightBarButtonItem = UIBarButtonItem(image: #imageLiteral(resourceName: "Ayarlar").withRenderingMode(.alwaysOriginal), style: .plain, target: self, action: #selector(oturumuKapat))
    }
    
    @objc fileprivate func oturumuKapat(){
        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)//.actionSheet-altdan görüntülensin demek
        
        let actionOturumuKapat = UIAlertAction(title: "Oturumu Kapat", style: .destructive) { (_) in
            
            guard let _ = Auth.auth().currentUser?.uid else {return}
            do {
                try Auth.auth().signOut()
                let oturumAcController = OturumAcController()
                let navController = UINavigationController(rootViewController: oturumAcController)
                navController.modalPresentationStyle = .fullScreen
                self.present(navController, animated: true, completion: nil)
                
            } catch let oturumuKapatmaHatasi {
                print("Oturumu kapatırken hata oluştu: ",oturumuKapatmaHatasi)
            }
        }//.destructive-yazı fontu kırmızı
        
        
        
        let actionIptalEt = UIAlertAction(title: "Iptal Et", style: .cancel, handler: nil)
        
        alertController.addAction(actionOturumuKapat)
        alertController.addAction(actionIptalEt)
        present(alertController, animated: true, completion: nil)
    }
    
    //paylaşım ksımındaki hücreleri oluşturmak
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return paylasimlar.count
    }
    
    //oluşturulan her bir hücrenin boyutunu ayarlamağa yarar
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if gridGorunum {
            let genislik = (view.frame.width - 5)/3
            return CGSize(width: genislik, height: genislik)
        } else {
            return CGSize(width: view.frame.width, height: view.frame.width + 200)
        }
    }
    
    //section'lar arası boşluğu ayarlama
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 2
    }
    
    //hücreler arası boşluğu ayarlama
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 2
    } 
    
    //hücreler oluşturulurken çağrılan metot
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if gridGorunum {
            let paylasimHucre = collectionView.dequeueReusableCell(withReuseIdentifier: paylasimHucreID, for: indexPath) as! KullaniciPaylasimFotoCell
            //kullanıcı profil sayfasında resimlerin paylaşıldığı yer
            paylasimHucre.paylasim = paylasimlar[indexPath.row]
            return paylasimHucre
        } else {
            let hucre = collectionView.dequeueReusableCell(withReuseIdentifier: listePaylasimHucreID, for: indexPath) as! AnaPaylasimCell
            //kullanıcı profil sayfasında resimlerin paylaşıldığı yer
            hucre.paylasim = paylasimlar[indexPath.row]
            return hucre
        }
    }
    
    //burda bir alan oluşturuyoruz ama bunu footer veya header olduğunu aşağıda yazdığımız extensionda belirtiyoruz
    override func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "headerID", for: indexPath) as! KullaniciProfilHeader
        //kullanici profilheader'ı buraya bağladık
        header.gecerliKullanici = gecerliKullanici
        header.delegate = self
        return header
    }
    
    var gecerliKullanici : Kullanici?
    
    fileprivate func kullaniciyiGetir(){
        
        //guard let gecerliKullaniciID = Auth.auth().currentUser?.uid else {return}
        //arama kısmındaki kullanıcının profiline erişmek için
        let gecerliKullaniciID = kullaniciID ?? Auth.auth().currentUser?.uid ?? ""
        
        Firestore.firestore().collection("Kullanicilar").document(gecerliKullaniciID).getDocument { snapshot, hata in
            if let hata = hata {
                print("Kullanici bilgileri getirilemedi",hata)
                return
            }
            
            guard let kullaniciVerisi = snapshot?.data() else {return}
            //let kullaniciAdi = kullaniciVerisi["KullaniciAdi"] as? String
            self.gecerliKullanici = Kullanici(kullaniciVerisi: kullaniciVerisi)
            //header alanı yenilenecek
            //self.collectionView.reloadData()
            
            //bu fonksiyonda da reloaddata var diye iki kere reload yapmasın diye böyle yazdım
            self.paylasimlariGetirFireStore()
            
            //self.navigationItem.title = kullaniciAdi?.lowercased()
            self.navigationItem.title = self.gecerliKullanici?.kullaniciAdi.lowercased()
            print("kullaniciID : ",gecerliKullaniciID)
            print("kullaniciAdi : ",self.gecerliKullanici?.kullaniciAdi ?? "")
            
            self.collectionView.reloadData()
        }
    }
}

extension KullaniciProfilController : UICollectionViewDelegateFlowLayout{
    //header oluşturmak için(alan boyutunu hesaplar) - sizeforhead kısaca bunu yazınca metot çıkıyor
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        CGSize(width: view.frame.width, height: 200)
    }
    
    //footer oluşturmak için(alan boyutunu hesaplar) - sizeforfoot kısaca bunu yazınca metot çıkıyor
    /*func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        CGSize(width: view.frame.width, height: 200)
    }*/
}

extension KullaniciProfilController : KullaniciProfilHeaderDelegate {
    func gridGorunumuGec() {
        gridGorunum = true
        collectionView.reloadData()
    }
    
    func listeGorunumeGec() {
        gridGorunum = false
        collectionView.reloadData()
    }
}
