//
//  KullaniciProfilHeader.swift
//  InstagramClone
//
//  Created by Sahil Rzayev on 5/4/22.
//

import Foundation
import UIKit
import Firebase
import FirebaseFirestore
import SDWebImage

protocol KullaniciProfilHeaderDelegate {
    func gridGorunumuGec()
    func listeGorunumeGec()
}

class KullaniciProfilHeader : UICollectionViewCell{
    
    var delegate : KullaniciProfilHeaderDelegate?
    
    var takiptenCikar = "Takipten Çıkar"
    var takipEt = "Takip Et"
    
    //butona basınca algılaöıyor. o yüzden let yerine lazy var kullnadım ki aynı hiyerarşiye sahip nesneler birbirine erişebilsin ve algılasın
    lazy var btnProfilDuzenle:UIButton={
        let btn = UIButton(type: .system)
        btn.setTitleColor(.black, for: .normal)
        btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
        btn.layer.borderColor = UIColor.lightGray.cgColor
        btn.layer.borderWidth = 1
        btn.layer.cornerRadius = 5
        btn.addTarget(self, action: #selector(btnProfil_Takip_Duzenle), for: .touchUpInside)
        return btn
    }()
    
    @objc fileprivate func btnProfil_Takip_Duzenle() {
        guard let oturumAcanKullaniciID = Auth.auth().currentUser?.uid else {return}
        guard let gecerliKullaniciID = gecerliKullanici?.kullaniciID else {return}
        guard let gecerliKullanici = gecerliKullanici else {return}
        
        if btnProfilDuzenle.titleLabel?.text == takiptenCikar {
            Firestore.firestore().collection("TakipEdiyor").document(oturumAcanKullaniciID).updateData([gecerliKullaniciID : FieldValue.delete()]) { hata in
                if let hata = hata {
                    print("Takipten çıkarırken hata meydana geldi: ",hata.localizedDescription)
                }
                self.sayısalDegerler(oturumAcanKullaniciID: oturumAcanKullaniciID, gecerliKullanici: gecerliKullanici)
                print("\(self.gecerliKullanici?.kullaniciAdi ?? "") adlı kullanıcı takipten çıkarıldı")
                
                self.btnProfilDuzenle.backgroundColor = UIColor.rgbDonustur(red: 20, green: 155, blue: 240)
                self.btnProfilDuzenle.setTitleColor(.white, for: .normal)//takip et yazısı beyaz olucak
                self.btnProfilDuzenle.layer.borderColor = UIColor(white: 0, alpha: 0.3).cgColor
                self.btnProfilDuzenle.layer.borderWidth = 1
                self.btnProfilDuzenle.setTitle( self.takipEt, for: .normal)
            }
            return
        }
        
        let eklenecekDeger = [gecerliKullaniciID : 1]
        
        Firestore.firestore().collection("TakipEdiyor").document(oturumAcanKullaniciID).getDocument { snapshot, hata in
            if let hata = hata {
                print("Takip verisi alınamadı: ",hata.localizedDescription)
                return
            }
            //böyle bir document daha önce oluşturulmuş mu
            if snapshot?.exists == true {
                //updateData var olan document'e ekler yoksa hata verir
                Firestore.firestore().collection("TakipEdiyor").document(oturumAcanKullaniciID).updateData(eklenecekDeger) { hata in
                    if let hata = hata {
                        print("Takip verisi güncellemesi başarısız: ",hata.localizedDescription)
                        return
                    }
                    print("Takip işlemi başarılı")
                    self.btnProfilDuzenle.setTitle( self.takiptenCikar, for: .normal)
                    self.btnProfilDuzenle.setTitleColor(.black, for: .normal)
                    self.btnProfilDuzenle.backgroundColor = .white
                    self.btnProfilDuzenle.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
                    self.btnProfilDuzenle.layer.borderColor = UIColor.lightGray.cgColor
                    self.btnProfilDuzenle.layer.borderWidth = 1
                    self.btnProfilDuzenle.layer.cornerRadius = 5
                }
            } else {
                Firestore.firestore().collection("TakipEdiyor").document(oturumAcanKullaniciID).setData(eklenecekDeger) { hata in
                    if let hata = hata {
                        print("Takip verisi kaydı başarısız: ",hata.localizedDescription)
                        return
                    }
                    print("Takip işlemi başarılı")
                }
            }
        }
    }
    
    //---------------------------------------
    
    let lblPaylasim:UILabel={
        let lbl = UILabel()
        lbl.textAlignment = .center
        lbl.numberOfLines = 0 // text kısmındaki \n yaptığımızda alt satuır gözkmüyor o yüzden bunu ekledim
        return lbl
    }()
    
    let lblTakipci:UILabel={
        let lbl = UILabel()
        lbl.textAlignment = .center
        lbl.numberOfLines = 0
        return lbl
    }()
    
    let lblTakipEdiyor:UILabel={
        let lbl = UILabel()
        lbl.textAlignment = .center
        lbl.numberOfLines = 0
        return lbl
    }()
    
    //---------------------------------------
    
    let lblKullaniciAdi:UILabel={
        let lbl = UILabel()
        lbl.text = "Kullanici Adi"
        lbl.font = UIFont.boldSystemFont(ofSize: 15)
        return lbl
    }()
    
    //---------------------------------------
    
    lazy var btnGrid:UIButton={
        let btn = UIButton(type: .system)
        btn.setImage(#imageLiteral(resourceName: "Izgara"), for: .normal)
        btn.addTarget(self, action: #selector(btnGridPressed), for: .touchUpInside)
        return btn
    }() 
    
    @objc fileprivate func btnGridPressed() {
        btnGrid.tintColor = UIColor.anaMavi()
        btnListe.tintColor = UIColor(white: 0, alpha: 0.2)
        delegate?.gridGorunumuGec()
    }
    
    lazy var btnListe:UIButton={
        let btn = UIButton(type: .system)
        btn.setImage(#imageLiteral(resourceName: "Liste"), for: .normal)
        btn.tintColor=UIColor(white: 0, alpha: 0.2)
        btn.addTarget(self, action: #selector(btnListePressed), for: .touchUpInside)
        return btn
    }()
    
    @objc fileprivate func btnListePressed() {
        btnListe.tintColor = UIColor.anaMavi()
        btnGrid.tintColor = UIColor(white: 0, alpha: 0.2)
        delegate?.listeGorunumeGec()
    }
    
    let btnYerIsareti:UIButton={
        let btn = UIButton(type: .system)
        btn.setImage(#imageLiteral(resourceName: "Yer_Isareti"), for: .normal)
        btn.tintColor=UIColor(white: 0, alpha: 0.2)
        return btn
    }()
    
    //kullaniciprofilcontroller'dan buraya gecerlikullanici bilgilerini aktarıyoruz
    var gecerliKullanici : Kullanici? {
        //didset - geçerlikullanici nesnesine bir değer atanırsa gel burayı çalıştır
        didSet {
            //print("Header alanındaki geçerli kullanıcı nesnesine bir değer atandı : ",gecerliKullanici?.kullaniciAdi ?? "")
            takipButonuAyarla()
            guard let url = URL(string: gecerliKullanici?.profilGoruntuURL ?? "") else {return}
            imgProfilGoruntu.sd_setImage(with: url, completed: nil)
            lblKullaniciAdi.text = gecerliKullanici?.kullaniciAdi.lowercased()
        }
    }
    
    fileprivate func istatistikselVeriler(oturumAcanKullaniciID:String, gecerliKullanici:Kullanici){
        
        //-------------------------- Takip Eden Sayısı -----------------------
        Firestore.firestore().collection("TakipEdiyor").document(oturumAcanKullaniciID).addSnapshotListener({ snapshot, hata in
            if let hata = hata {
                print("Takip verisi alınamadı",hata.localizedDescription)
                return
            }
            guard let takipSayisi = snapshot?.data()?.count else {return}
            let attrText = NSMutableAttributedString(string: "\(takipSayisi)\n", attributes: [.font: UIFont.boldSystemFont(ofSize: 16)])
            attrText.append(NSAttributedString(string: "Takip Ediyor", attributes: [.foregroundColor:UIColor.darkGray, .font :UIFont.systemFont(ofSize: 14)]))
            self.lblTakipEdiyor.attributedText = attrText
        })
        
        
        //-------------------------- Paylaşım Sayısı -----------------------
        
        
        Firestore.firestore().collection("Paylasimlar").document(oturumAcanKullaniciID).collection("Fotograf_Paylasimlari").addSnapshotListener { querySnapshot, hata in
            if let hata = hata {
                print("Paylaşımlar getirilirken hata oluştu: ",hata.localizedDescription)
                return
            }
            guard let paylasimSayisi = querySnapshot?.count else {return}
            
            let attrText = NSMutableAttributedString(string: "\(paylasimSayisi)\n", attributes: [.font: UIFont.boldSystemFont(ofSize: 16)])
            attrText.append(NSAttributedString(string: "Paylaşım", attributes: [.foregroundColor:UIColor.darkGray, .font :UIFont.systemFont(ofSize: 14)]))
            self.lblPaylasim.attributedText = attrText
            
            }
        
        
        //-------------------------- Takipçi Sayısı -----------------------
        var takipci = [String]()
        Firestore.firestore().collection("Kullanicilar").addSnapshotListener { queryShapshot, hata in
            if let hata = hata {
                print("Kullanıcı bilgileri getirilirken hata meydana geldi: \(hata.localizedDescription)")
                return
            }
            queryShapshot?.documentChanges.forEach({ degisiklik in
                    let kullanici = Kullanici(kullaniciVerisi: degisiklik.document.data())
                    if kullanici.kullaniciID != Auth.auth().currentUser?.uid {
                        Firestore.firestore().collection("TakipEdiyor").document(kullanici.kullaniciID).addSnapshotListener({ snapshot, hata in
                            if let hata = hata {
                                print("Takip verisi alınamadı",hata.localizedDescription)
                                //return
                            }
                            guard let takipciSayisi = snapshot?.data() else {return}
                            takipciSayisi.keys.forEach { k in
                                if k == Auth.auth().currentUser?.uid {
                                    //print("kkk : ",k)
                                    takipci.append(k)
                                }
                            }
                            let attrText = NSMutableAttributedString(string: "\(takipci.count)\n", attributes: [.font: UIFont.boldSystemFont(ofSize: 16)])
                            attrText.append(NSAttributedString(string: "Takipçi", attributes: [.foregroundColor:UIColor.darkGray, .font :UIFont.systemFont(ofSize: 14)]))
                            self.lblTakipci.attributedText = attrText
                            takipci.removeAll()
                            
                        })
                    }
            })}
    }
    
    fileprivate func sayısalDegerler(oturumAcanKullaniciID:String, gecerliKullanici:Kullanici){
        //-------------------------- Takip Eden Sayısı -----------------------
        Firestore.firestore().collection("TakipEdiyor").document(gecerliKullanici.kullaniciID).getDocument(completion: { docSnapshot, hata in
            if let hata = hata {
                print("Takip verisi alınamadı",hata.localizedDescription)
                return
            }
            
            if let doc = docSnapshot, doc.exists {
                print("geç")
            }else {
                let attrText = NSMutableAttributedString(string: "0\n", attributes: [.font: UIFont.boldSystemFont(ofSize: 16)])
                attrText.append(NSAttributedString(string: "Takip Ediyor", attributes: [.foregroundColor:UIColor.darkGray, .font :UIFont.systemFont(ofSize: 14)]))
                self.lblTakipEdiyor.attributedText = attrText
            }
        })
        Firestore.firestore().collection("TakipEdiyor").document(gecerliKullanici.kullaniciID).addSnapshotListener({ snapshot, hata in
            if let hata = hata {
                print("Takip verisi alınamadı",hata.localizedDescription)
                return
            }
            guard let takipSayisi = snapshot?.data()?.count else {return}
            
            //print("gözükmeyen şey : ",takipSayisi)
                let attrText = NSMutableAttributedString(string: "\(takipSayisi)\n", attributes: [.font: UIFont.boldSystemFont(ofSize: 16)])
                attrText.append(NSAttributedString(string: "Takip Ediyor", attributes: [.foregroundColor:UIColor.darkGray, .font :UIFont.systemFont(ofSize: 14)]))
                self.lblTakipEdiyor.attributedText = attrText
            
        })
        
        
        //-------------------------- Paylaşım Sayısı -----------------------
        
        
        Firestore.firestore().collection("Paylasimlar").document(gecerliKullanici.kullaniciID).collection("Fotograf_Paylasimlari").addSnapshotListener { querySnapshot, hata in
            if let hata = hata {
                print("Paylaşımlar getirilirken hata oluştu: ",hata.localizedDescription)
                return
            }
            guard let paylasimSayisi = querySnapshot?.count else {return}
            
            let attrText = NSMutableAttributedString(string: "\(paylasimSayisi)\n", attributes: [.font: UIFont.boldSystemFont(ofSize: 16)])
            attrText.append(NSAttributedString(string: "Paylaşım", attributes: [.foregroundColor:UIColor.darkGray, .font :UIFont.systemFont(ofSize: 14)]))
            self.lblPaylasim.attributedText = attrText
            
            }
        
        
        //-------------------------- Takipçi Sayısı -----------------------
        var takip = [String]()
        var sayi = 0
        Firestore.firestore().collection("Kullanicilar").addSnapshotListener { queryShapshot, hata in
            if let hata = hata {
                print("Kullanıcı bilgileri getirilirken hata meydana geldi: \(hata.localizedDescription)")
                return
            }
            queryShapshot?.documentChanges.forEach({ degisiklik in
                    let kullanici = Kullanici(kullaniciVerisi: degisiklik.document.data())
                //tüm user
                //print("kid : ",kullanici.kullaniciID,"-",kullanici.kullaniciAdi)
                //tıkladığımız user
                //print("gkid : ",gecerliKullanici.kullaniciID,"-",gecerliKullanici.kullaniciAdi)
                if kullanici.kullaniciID != gecerliKullanici.kullaniciID {
                        Firestore.firestore().collection("TakipEdiyor").document(kullanici.kullaniciID).addSnapshotListener({ snapshot, hata in
                            if let hata = hata {
                                print("Takip verisi alınamadı",hata.localizedDescription)
                                return
                            }
                            guard let takipciSayisi = snapshot?.data() else {return}
                            takipciSayisi.keys.forEach { k in
                                if k == gecerliKullanici.kullaniciID {
                                    //print("kkk : ",k)
                                    takip.append(k)
                                    sayi+=1
                                }
                                print(takip.count)
                            }
                            let attrText = NSMutableAttributedString(string: "\(sayi)\n", attributes: [.font: UIFont.boldSystemFont(ofSize: 16)])
                            attrText.append(NSAttributedString(string: "Takipçi", attributes: [.foregroundColor:UIColor.darkGray, .font :UIFont.systemFont(ofSize: 14)]))
                            self.lblTakipci.attributedText = attrText
                            takip.removeAll()
                            return
                        })
                    }
            })}
        
    }
    
    fileprivate func takipButonuAyarla(){
        guard let oturumAcanKullaniciID = Auth.auth().currentUser?.uid else {return}
        guard let gecerliKullaniciID = gecerliKullanici?.kullaniciID else {return}
        guard let gecerliKullanici = gecerliKullanici else {return}
        if oturumAcanKullaniciID != gecerliKullaniciID {
            sayısalDegerler(oturumAcanKullaniciID: oturumAcanKullaniciID, gecerliKullanici: gecerliKullanici)
            Firestore.firestore().collection("TakipEdiyor").document(oturumAcanKullaniciID).addSnapshotListener { snapshot, hata in
                if let hata = hata {
                    print("Takip verisi alınamadı",hata.localizedDescription)
                    return
                }
                guard let takipVerisi = snapshot?.data() else {return}
                
                //eğer ben bu kullanıcıyı takip ediyorsam takipten çıkar butonu yazılsın
                if let veri = takipVerisi[gecerliKullaniciID] {
                    let takip = veri as? Int ?? 0
                    print(takip)
                    if takip == 1 {
                        self.btnProfilDuzenle.setTitle(self.takiptenCikar, for: .normal)
                        return
                    }
                } else {
                    self.btnProfilDuzenle.setTitle( self.takipEt, for: .normal)
                    self.btnProfilDuzenle.backgroundColor = UIColor.rgbDonustur(red: 20, green: 155, blue: 240)
                    self.btnProfilDuzenle.setTitleColor(.white, for: .normal)//takip et yazısı beyaz olucak
                    self.btnProfilDuzenle.layer.borderColor = UIColor(white: 0, alpha: 0.3).cgColor
                    self.btnProfilDuzenle.layer.borderWidth = 1
                }
            }
        } else {
            istatistikselVeriler(oturumAcanKullaniciID: oturumAcanKullaniciID, gecerliKullanici: gecerliKullanici)
            self.btnProfilDuzenle.setTitle("Profil Düzenle", for: .normal)
            self.btnProfilDuzenle.isEnabled = false
        }
    }
    
    let imgProfilGoruntu : UIImageView = {
        let img = UIImageView()
        img.backgroundColor = .yellow
        return img
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        //backgroundColor = .red
        addSubview(imgProfilGoruntu)
        let goruntuBoyut : CGFloat = 90 //width ve height 90
        imgProfilGoruntu.anchor(top: topAnchor, bottom: nil, leading: self.leadingAnchor, trailing: nil, paddingTop: 15, paddingBottom: 0, paddingLeft: 15, paddingRight: 0, width: goruntuBoyut, height: goruntuBoyut)
        imgProfilGoruntu.layer.cornerRadius = goruntuBoyut/2
        imgProfilGoruntu.clipsToBounds = true
        
        //---------------------------------------
        
        toolbarOlustur()
        
        //---------------------------------------
        
        addSubview(lblKullaniciAdi)
        //kullanici adını prof foto ile grid butonu arasında konumlandırma
        lblKullaniciAdi.anchor(top: imgProfilGoruntu.bottomAnchor, bottom: btnGrid.topAnchor, leading: leadingAnchor, trailing: trailingAnchor, paddingTop: 5, paddingBottom: 0, paddingLeft: 15, paddingRight: 15, width: 0, height: 0)
        
        //---------------------------------------
        
        kullaniciDurumBilgisiGoster()
        
        //---------------------------------------
        
        addSubview(btnProfilDuzenle)
        btnProfilDuzenle.anchor(top: lblPaylasim.bottomAnchor, bottom: nil, leading: lblPaylasim.leadingAnchor, trailing: lblTakipEdiyor.trailingAnchor, paddingTop: 10, paddingBottom: 0, paddingLeft: 0, paddingRight: 0, width: 0, height: 35)
        
        //profilFotoYukle()
    }
    
    fileprivate func toolbarOlustur(){
        
        let ustAyracView = UIView()
        ustAyracView.backgroundColor = UIColor.lightGray
        let altAyracView = UIView()
        altAyracView.backgroundColor = UIColor.lightGray
        
        let stackView = UIStackView(arrangedSubviews: [btnGrid,btnListe,btnYerIsareti])
        addSubview(stackView)
        addSubview(ustAyracView)
        addSubview(altAyracView)
        stackView.axis = .horizontal//varsayılan değeri zaten horizontal
        stackView.distribution = .fillEqually//stackview içindeki nesnelerin eşit oranda boyut kazanmasını sağlamak
        stackView.anchor(top: nil, bottom: self.bottomAnchor, leading: self.leadingAnchor, trailing: self.trailingAnchor, paddingTop: 0, paddingBottom: 0, paddingLeft: 0, paddingRight: 0, width: 0, height: 60)
        
        ustAyracView.anchor(top: stackView.topAnchor, bottom: nil, leading: leadingAnchor, trailing: trailingAnchor, paddingTop: 0, paddingBottom: 0, paddingLeft: 0, paddingRight: 0, width: 0, height: 0.5)
        altAyracView.anchor(top: stackView.bottomAnchor, bottom: nil, leading: leadingAnchor, trailing: trailingAnchor, paddingTop: 0, paddingBottom: 0, paddingLeft: 0, paddingRight: 0, width: 0, height: 0.5)
    }
    
    fileprivate func kullaniciDurumBilgisiGoster(){
        let stackView = UIStackView(arrangedSubviews: [lblPaylasim,lblTakipci,lblTakipEdiyor])
        addSubview(stackView)
        stackView.distribution = .fillEqually
        stackView.anchor(top: topAnchor, bottom: nil, leading: imgProfilGoruntu.trailingAnchor, trailing: trailingAnchor, paddingTop: 15, paddingBottom: 0, paddingLeft: 15, paddingRight: -15, width: 0, height: 50)
    }
    
    /*fileprivate func profilFotoYukle(){
        guard let gecerliKullaniciID = Auth.auth().currentUser?.uid else {return}
        Firestore.firestore().collection("Kullanicilar").document(gecerliKullaniciID).getDocument { snapshot, hata in
            if let hata = hata {
                print("Kullanici bilgisi getirilemedi : ",hata)
                return
            }
            
            guard let kullaniciVerisi = snapshot?.data() else {return}
            guard let profilGoruntuURL = kullaniciVerisi["ProfilGoruntuURL"] as? String else {return}
            guard let url = URL(string: profilGoruntuURL) else {return}
            self.imgProfilGoruntu.sd_setImage(with: url, completed: nil)
        }
    }*/
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
